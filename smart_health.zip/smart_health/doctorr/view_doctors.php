<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Health Prediction</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">


    <link rel="stylesheet" href="/smart_health/css/style.css">
</head>
<body>

<?php include '../iincludes/header.php'; ?>
<div class="container mt-4">
<h3 class="mb-4"><b>My Profile</b></h3>
<?php
session_start();
include '../config/db.php';
$conn = mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DBNAME);
$doctor_email = $_SESSION['doctor_email'];

$qry = "SELECT * FROM doctors WHERE email='$doctor_email'";

$result = mysqli_query($conn,$qry);

if(mysqli_num_rows($result) > 0)
{
    echo "<table class='table table-hover table-bordered'>";
    echo "<tr class='table-dark'>";
    echo "<th>Doctor ID</th>";
    echo "<th>Name</th>";
    echo "<th>Specialization</th>";
    echo "<th>Contact</th>";
    echo "<th>Action</th>";
    echo "</tr>";
    while($row = mysqli_fetch_array($result))
    {
        echo "<tr>";
        echo "<td>$row[0]</td>";
        echo "<td>$row[1]</td>";
        echo "<td>$row[2]</td>";
        echo "<td>$row[3]</td>";
        echo "<td><a class='btn btn-info btn-sm' href='edit_doctor.php?id=$row[0]'>Edit Profile</a></td>";
        echo "</tr>";
    }

    echo "</table>";
}
else
{
    echo "<h2 class='text-warning'>No Record Found !!!</h2>";
}
mysqli_close($conn);
?>

<a href="../admin/dashboard.php" class="btn btn-primary">Back to Dashboard</a> 
</div>

<?php include '../iincludes/footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
