
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Health | Home</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="css/style.css">
</head>

<body>


<?php include("iincludes/header.php"); ?>

<!-- HOME SECTION -->
<div class="home">
    <div class="home-text">
        <h1>Smart Health Prediction System</h1>
        <p>
            This system helps users understand possible health issues 
            based on the symptoms they select and provides simple guidance.
        </p>
        <a href="user/register.php" class="btn-start">Get Started</a>

    </div>

    <div class="home-image">
        <img src="/smart_health/images/healthh.png" alt="Smart Health">
    </div>
</div>
 
<!-- HOW IT WORKS -->
<h2 class="title">How It Works</h2>

<div class="steps">
    <div class="step-box">
        <h3>Step 1</h3>
        <p>Register & Login</p>
    </div>

    <div class="step-box">
        <h3>Step 2</h3>
        <p>Select Symptoms</p>
    </div>

    <div class="step-box">
        <h3>Step 3</h3>
        <p>View Result</p>
    </div>
</div>

<?php include("iincludes/footer.php"); ?>
 
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
