 
<?php
     $msg ="";
     if(isset($_POST['btn_login'])){
        $username=$_POST['username'];
        $password=$_POST['password'];
        include'../config/db.php';
         $conn =mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DBNAME);
         $qry = "select * from users where  email='$username' and password='$password'";
         $result = mysqli_query($conn, $qry);
         if(mysqli_num_rows($result) > 0){
             $r=mysqli_fetch_array($result);
             session_start();
             $_SESSION['uid']=$r[0];
             header("location:select_symptoms.php");
             }
               else 
                $msg="<b class='text-danger m-5'>Invaild username and password!!!!!!</b>";
                mysqli_close($conn);
               }   
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>User Login</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">

    <link href="/smart_health/css/style.css" rel="stylesheet">
</head>
<body>

<?php include("../iincludes/header.php"); ?>

<div class="container-fulid mt-5">
    <div class="row justify-content-center">
        <div class="col-md-4">

            <div class="card shadow p-4">
                <h3 class="text-center mb-3">User Login</h3>

                <form method="post">
                    <div class="mb-3">
                        <input type="email"  name='username'class="form-control" placeholder="Email" required>
                    </div>

                    <div class="mb-3">
                        <input type="password" name= ' password 'class="form-control" placeholder=" Password" required>
                    </div>

                    <button type='submit' class="btn btn-success w-100">Login</button>
                    <div class="text-center mt-3">
   Don’t have an account? 
   <a href="register.php" class="text-success">Register here</a>
</div>

                </form>
                 <?php
                 if(isset($_POST['btn_login'])){
                    $username = $_POST['username'];
                    $password = $_POST['password'];
                     include '../smart_health/config/db.php';
                     $conn =mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DBNAME);
                    $qry = "select * form admin where username = '$username' and password='$password'";
                    $result = mysqli_query($conn,$qry);
                     if(mysqli_num_row($result)>0){
                         header("location:dashboard.php");
                          }
                          else{
                            echo "<b class='text-danger m-5'>Invalid Username & password!!!!!</b>";
                         }
                         mysqli_close($conn);

                 }
                 ?>
            
            </div>

        </div>
    </div>
</div>

<?php include("../iincludes/footer.php"); ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
