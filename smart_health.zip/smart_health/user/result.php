<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Health Prediction</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">

   
    <link rel="stylesheet" href="/smart_health/css/style.css">
</head>
<body>

<?php include '../iincludes/header.php'; ?>

<div class="container mt-5" style="min-height:550px;">
    <h3>Predication Result</h3>

     <div class="alert alert-info">
        Based on selected symptoms,you may have: <strong>
            <?php
              include'../config/db.php';
              $symptomid = $_POST['symptoms'];
              $s = implode(",", $symptomid);
              $conn=mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DBNAME);
              $qry="SELECT d.disease_id, d.disease_name, d.description,
              COUNT(ds.symptom_id) AS match_count FROM disease_symptom ds JOIN diseases d 
              ON ds.disease_id = d.disease_id WHERE ds.symptom_id IN ($s) GROUP BY d.disease_id ORDER BY match_count DESC LIMIT 1";
             $result = mysqli_query($conn, $qry);
             if(mysqli_num_rows($result)>0){
              while ($row = mysqli_fetch_assoc($result)){
               echo "<br>".$row['disease_name'].":".$row['description'];
              }
            }
             else{
              echo "No Match Found!!!!";
              }
            ?>
     </strong>
     </div>
           <a href="select_symptoms.php" class="btn btn-secondary">Check Again ></a>

<?php include '../iincludes/footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

     