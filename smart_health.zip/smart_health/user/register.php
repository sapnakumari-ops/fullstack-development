<?php
   $msg = "";
    if(isset($_POST['btn_reg'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $pwd = password_hash($_POST['password'], PASSWORD_DEFAULT); 
    $no = $_POST['phone'];

    include '../smart_health/config/db.php';
    $conn = mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DBNAME);

    $qry= "INSERT INTO users(name,email,password,gender,mobile_no) 
           VALUES ('$name','$email','$pwd','$gender','$no')";
    mysqli_query($conn,$qry);

    if(mysqli_affected_rows($conn)>0){
        $msg="<b class='text-success'>Signup Successful!</b>";
    } else {
        $msg="<b class='text-danger'>Error in Signup. Try Again!</b>";
    }
    mysqli_close($conn);
}
?>
  <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>User Registration</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">

    <link href="/smart_health/css/style.css" rel="stylesheet">
    <script>
         function validate(){
             let email = document.getElementById("t2").value;
             XMLHttpRequest obj = new XMLHttpRequest();
             obj.open("get","validateemail.php?eid="+email,true);
             obj.send();
             obj.onreadystatechange=fuction(){
                if(obj.readyState==4 && obj.status==200){
                     document.getElementById("emailMsg").innerHTML= obj.responseText;
                }
             }

         }
        </script>
</head>
<body>

<?php include("../iincludes/header.php"); ?>

<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-4">

            <div class="card shadow p-4">
                <h3 class="text-center mb-3">User Registration</h3>

                <form method="post">
                    <div class="mb-3">
                        
                <div class="mb-3">
    <input type="text" name="name" class="form-control" placeholder="Full name" required>
      </div>
         <div class="mb-3"> 
            <input type="email" name="email"class="form-control" placeholder="Email" required>
                </div>

                    <div class="mb-3">
                    
                        <input type="password"  name =" password" class="form-control" placeholder=" Password" required>
                    </div>

                    <div class="mb-3">
                        
                        <input type="password" name ="cpassword" class="form-control" placeholder="Confirm password" required>
                    </div>
                   <div>
                    <select name="gender" class="form-control mb-3">
                        <option>Choose Gender</option>
                        <option>Male </option>
                         <option> Female</option>
                       </select>
                    </div>
                    <div class="mb-3">
                
                        <input type="number" name ="phone" class="form-control" placeholder="Mobile Number" required>
                    </div>

                    <button  type="submit" name ="btn_reg" class="btn btn-success w-100">Register</button>
               
     <div class="text-center mt-3">
       Already have an account? 
   <a href="login.php" class="text-primary">Go to Login</a>
</div>

                </form>

              <?php echo $msg; ?>
                
            </div>

        </div>
    </div>
</div>

<?php include("../iincludes/footer.php"); ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
