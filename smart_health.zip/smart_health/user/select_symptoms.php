    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Select Symptoms</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">

    <link rel="stylesheet" href="/smart_health/css/style.css">
</head>

<body>

<?php include '../iincludes/header.php'; ?>

<div class="container mt-5" style="min-height: 550px;">
    <h3>Select Your Symptoms</h3>

    <form action="result.php" method="post">

       <?php
$conn = mysqli_connect("localhost", "root", "", "smart_health");
$qry = "SELECT * FROM symptoms";
$result = mysqli_query($conn, $qry);
$i = 0;

while ($row = mysqli_fetch_assoc($result)) {
    if ($i == 0) {
        echo "<div class='row mb-2'>";
    }

    echo "<div class='col-sm-2'>";
    echo "<div class='form-check'>";
    echo "<input type='checkbox' name='symptoms[]' value='".$row['symptom_id']."' class='form-check-input'/>";
    echo "<label class='form-check-label'>".$row['symptom_name']."</label>";
    echo "</div>";
    echo "</div>";

    $i++;

    if ($i == 6) {
        echo "</div>";
        $i = 0;
    }
}

if ($i != 0) {
    echo "</div>";
}

mysqli_close($conn);
?>


        <button class="btn btn-primary mt-3" style="width: 200px;">
            Predict Disease
        </button>

    </form>
</div>

<?php include '../iincludes/footer.php'; ?>

</body>
</html>