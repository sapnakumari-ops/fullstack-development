<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Health Prediction</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">

    <link rel="stylesheet" href="/smart_health/css/style.css">
</head>
<body>

<?php include 'iincludes/header.php'; ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card shadow-lg border-0 rounded-4">
                <div class="card-header bg-gradient text-white text-center rounded-top-4" 
                     style="background: linear-gradient(90deg, #007bff,  #1fbdd9);">
                     <h3 class="mb-1 text-primary">Contact Us</h3>

                </div>
                <div class="card-body p-4">
                    <form method="post" action="">
                        <div class="form-floating mb-3">
                            <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required>
                            <label for="name">Your Name</label>
                        </div>

                        <div class="form-floating mb-3">
                            <input type="email" name="email" class="form-control" id="email" placeholder="Your Email" required>
                            <label for="email">Your Email</label>
                        </div>

                        <div class="form-floating mb-3">
                            <textarea name="message" class="form-control" id="message" placeholder="Write your message..." style="height: 120px;" required></textarea>
                            <label for="message">Message</label>
                        </div>

                        <button type="submit" name="submit" class="btn btn-primary btn-lg w-100 rounded-pill">
                            🚀 Send Message
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

   <?php
if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];


    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<p class='text-danger'>Invalid email format!</p>";
    } else {
        // Agar email sahi hai to database me insert karo
        include 'config/db.php';
        $conn = mysqli_connect(HOSTNAME, USERNAME, PASSWORD, DBNAME);

        $qry = "INSERT INTO contact (name, email, message) VALUES ('$name', '$email', '$message')";
        if(mysqli_query($conn, $qry)){
            echo "<p class='text-success mt-3'>Message sent successfully!</p>";
        } else {
            echo "<p class='text-danger mt-3'>Error sending message.</p>";
        }
        mysqli_close($conn);
    }
}
?>


<?php include 'iincludes/footer.php'; ?>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
