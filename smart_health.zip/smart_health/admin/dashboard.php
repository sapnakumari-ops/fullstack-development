 
 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Health Prediction</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="/smart_health/css/style.css">
    <title>Admin Dashboard</title>

<style>
    body{
        margin:0;
        font-family:'Poppins', 'Roboto', sans-serif;
        background: white;
        min-height:100vh;
    }

    h1{
        text-align:center;
        padding:30px 0;
        color:#31b1c4;
        letter-spacing:1px;
    }

   .dashboard {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 40px;
    padding: 40px 80px;


    }

    .card{
        background:#fff;
        border-radius:8px;
        padding:25px;
        text-align:center;
        box-shadow:0 10px 25px;
        transition:0.3s;
        position:relative;
        overflow:hidden;
    }

    .card::before{
       
        position:absolute;
        top:0;
        left:0;
        width:100%;
        height:6px;
        background:linear-gradient(to right,#2196f3,#21cbf3);
    }

    .card:hover{
        transform:translateY(-8px);
        box-shadow:0 15px 35px rgba(36, 185, 190, 0.15);
    }

    .card h2{
        margin-top:10px;
        margin-bottom:8px;
        color:#222;
    }

    .card p{
        font-size:14px;
        color:#666;
        margin-bottom:20px;
    }

    .btn-group{
        display:flex;
        justify-content:center;
        gap:12px;
    }

    button{
        padding:9px 18px;
        border:none;
        border-radius:20px;
        font-size:14px;
        cursor:pointer;
        transition:0.3s;
    }

    .add-blue{background:#2196f3;color:#fff;}
    .add-green{background:#4caf50;color:#fff;}
    .add-yellow{background:#ffc107;color:#000;}
    .add-cyan{background:#00bcd4;color:#fff;}

    .view{
        background:#f1f1f1;
        color:#333;
    }

    button:hover{
        opacity:0.85;
        transform:scale(1.05);
    }

    .mapping{
        margin:40px auto 0;
        width:60%;
    }

    .logout{
        text-align:center;
        margin:40px 0;
    }

    .logout button{
        background:#e53935;
        color:#fff;
        padding:12px 30px;
        border-radius:25px;
        font-size:16px;
        box-shadow:0 6px 15px rgba(0,0,0,0.2);
    }

    @media(max-width:768px){
        .dashboard{
            padding:0 20px;
        }
        .mapping{
            width:90%;
        }
    }
</style>
</head>
<body >
<?php include '../iincludes/header.php'; ?>
<div class="container-fluid mt-4"> 
    <h1><b>Admin Dashboard</b></h1>

<div class="dashboard">

    <div class="card">
        <h2>Manage Symptoms</h2>
        <p>Add, View, Edit, Delete Symptoms</p>
        <div class="btn-group">
            <button class="add-blue" onclick="location.href='add_symptom.php'">Add</button>
            <button class="view" onclick="location.href='view_symptoms.php'">View</button>
        </div>
    </div>

    <div class="card">
        <h2>Manage Diseases</h2>
        <p>Add, View, Edit, Delete Diseases</p>
        <div class="btn-group">
            <button class="add-green" onclick="location.href='add_disease.php'">Add</button>
            <button class="view"onclick="location.href='view_disease.php'">View</button>
        
        </div>
    </div>

    <div class="card">
        <h2>Manage Doctors</h2>
        <p>Add, View, Edit, Delete Doctors</p>
        <div class="btn-group">
            <button class="add-yellow" onclick="location.href='add_doctor.php'">Add</button>
            <button class="view"  onclick="location.href='view_doctors.php'">View</button>
        </div>
    </div>
    </div>

<div class="mapping">
    <div class="card">
        <h2>Disease–Symptom Mapping</h2>
        <p>Map symptoms with diseases</p>
        <div class="btn-group">
            <button class="add-cyan"onclick="location.href='map_disease_symptom.php'">Map</button>
            <button class="view" onclick="location.href='view_mapping.php'">View Mapping</button>
        </div>
    </div>
</div>

<div class="logout">
    <button onclick="location.href='logout.php'" class="btn btn-danger">Logout</button>
</div>

</div>

<?php include '../iincludes/footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
