<?php 
   session_start();
    if(!isset($_SESSION['userid'])){
        header("location:login.php");
    }
$msg = "";
include '../config/db.php';
if(isset($_POST['add_symptom'])){
    $sname = $_POST['symptom_name'];
     $conn =mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DBNAME);
    if(!$conn){
        die("Connection Failed: " . mysqli_connect_error());
    }
    $qry = "INSERT INTO symptoms(symptom_name)  VALUES('$sname')";
    mysqli_query($conn, $qry);
    if(mysqli_affected_rows($conn) > 0)
        $msg = "<b class='text-success'>Symptom Added Successfully !!!</b>";
    else
        $msg = "<b class='text-danger'>Error in adding Symptom !!!</b>";

    mysqli_close($conn);
}
  if(isset($_POST['sid'])){
    $sid =$_GET['sid'];
    $conn =mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DBNAME);
    $qry =" select * from symptons where symptom_id=$id";
    $result = mysqli_query($conn,$qry);
    $row=mysqli_fetch_array($result);
  }
    if(isset($_POST['update_symptom']))
        {
        $id=$_POST['id'];
         $name=$_POST['symptom'];
         $conn =mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DBNAME);
       $qry ="update systoms set symptom_name='$name' where symptom_id=$id";
        $result = mysqli_query($conn,$qry);
        header("location:view_symptoms.php");
        }
        ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Health Prediction</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">

   
    <link rel="stylesheet" href="/smart_health/css/style.css">
</head>
<body>

<?php include '../iincludes/header.php'; ?>

<div class="container mt-5" style="min-height:550px;">

     <?php
       if(isset($_GET['sid']))
        echo "<h3>Edit Symptom</h3>";
       else
        echo "<h3>Add Symptom</h3>";
     ?>
    <form method="post">
        <?php
         if(isset($_GET['sid']))
            echo "<input type ='hidden' name='id' value='$row[0]'/>";
        ?>
    <input type="text" value="<?php
           if(isset($_GET['sid']))
            echo $row[1];?>"
           name="symptom"
           class="form-control mb-3"
           placeholder="Symptom Name"
           required>
    <button type="submit"
            name="<?php
             if(isset($_GET['sid']))
                echo "Update Symptom";
       else
        echo "Add Symptom";
     ?></button>
    <a class="btn btn-warning" href="../admin/dashboard.php">Goto Dashboard</a>  
</form>
<br>
<?php echo $msg; ?>
    
</div>

<?php include '../iincludes/footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
