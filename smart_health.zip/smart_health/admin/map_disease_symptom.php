<?php 
   session_start();
    f(!isset($_SESSION['userid'])){
        header("location:login.php");
    }
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Health Prediction</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">

   
    <link rel="stylesheet" href="/smart_health/css/style.css">
</head>
<body>
<?php include '../iincludes/header.php'; ?>

<div class="container mt-4">
<h3>Disease–Symptom Mapping</h3>

<form method="post">

<label><b>Disease</b></label>
<select name="disease" class="form-control mb-3" required>
<option value="">-------</option>

<?php
$conn = mysqli_connect("localhost","root","","smart_health");
$qry = "SELECT * FROM diseases";
$result = mysqli_query($conn,$qry);

while($row = mysqli_fetch_assoc($result)){
    echo "<option value='".$row['disease_id']."'>".$row['disease_name']."</option>";
}
mysqli_close($conn);
?>
</select>
<label><b> Symptoms </b></label>
<div class="row">
<?php
include '../config/db.php';
     $conn =mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DBNAME);
$qry = "SELECT * FROM symptoms";
$result = mysqli_query($conn,$qry);

while($row = mysqli_fetch_assoc($result)){
?>
    <div class="col-md-2 mb-2">
        <div class="form-check">
            <input type="checkbox"
                   name="symptoms[]"
                   value="<?php echo $row['symptom_id']; ?>"
                   class="form-check-input">

            <label class="form-check-label">
                <?php echo $row['symptom_name']; ?>
            </label>
        </div>
    </div>
<?php
}
mysqli_close($conn);
?>
<div class="mt-3 d-flex justify-content-center mb-4">
    <button type="submit" name="btn_map"
        class="btn btn-success me-3"
        style="padding:10px 58px;">
        Map
    </button>
    <a href="../admin/dashboard.php"
       class="btn btn-primary"
       style="padding:10px 58px;">
        Dashboard
    </a>
</div>
<?php
if(isset($_POST['btn_map'])){
    $conn = mysqli_connect("localhost","root","","smart_health");
    $did = $_POST['disease'];
    $symptoms = $_POST['symptoms'];

    foreach($symptoms as $sid){
        mysqli_query($conn,
            "INSERT INTO disease_symptom(disease_id,symptom_id)
             VALUES($did,$sid)"
        );
    }

    if(mysqli_affected_rows($conn) > 0)
        echo "<b class='text-success'>Mapping Saved !!!</b>";
    else
        echo "<b class='text-danger'>Error In Mapping !!!</b>";
    mysqli_close($conn);
}
?>
</form>
</div>
<?php include '../iincludes/footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
