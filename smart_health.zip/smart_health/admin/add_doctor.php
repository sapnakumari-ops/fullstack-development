//<?php 
   //session_start();
    //if(!isset($_SESSION['userid'])){
        //header("location:login.php");
    //}
$msg = "";
if(isset($_POST['add_doctor']))
{
    $name = $_POST['name'];
    $specialization = $_POST['specialization'];
    $contact = $_POST['contact'];
   include '../config/db.php';
     $conn =mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DBNAME);
    if(!$conn){
        die("Connection Failed: " . mysqli_connect_error());
    }
    $qry = "INSERT INTO doctors(name, specialization, contact)
            VALUES('$name', '$specialization', '$contact')";
    mysqli_query($conn, $qry);
    if(mysqli_affected_rows($conn) > 0)
        $msg = "<b class='text-success'>Doctor Added Successfully !!!</b>";
    else
        $msg = "<b class='text-danger'>Error in adding Doctor !!!</b>";

    mysqli_close($conn);
}
  if(isset($_POST['sid'])){
    $sid =$_GET['sid'];
    $conn =mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DBNAME);
    $qry =" select * from symptoms where symptom_id=$id";
    $result = mysqli_query($conn,$qry);
    $row=mysqli_fetch_array($result);
  }
    if(isset($_POST['update_symptom']))
        $id=$_POST['id'];
         $name=$_POST['symptom'];
         $conn =mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DBNAME);
       $qry =" select * from symptoms where symptom_id=$id";
        $result = mysqli_query($conn,$qry);
        header("location:view_symptoms.php");
          
        ?>
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Health Prediction</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">

    <link rel="stylesheet" href="/smart_health/css/style.css">
</head>
<body>
<?php include '../iincludes/header.php'; ?>

 <div class="container  mt-5" style=" mini-height: 550px;">
  <h3>Add Doctor</h3>

<form method="post">

    <input type="text" 
           name="name" 
           class="form-control mb-3" 
           placeholder="Doctor Name" 
           required>
    <input type="text" 
           name="specialization" 
           class="form-control mb-3" 
           placeholder="Specialization" 
           required>
    <input type="text" 
           name="contact" 
           class="form-control mb-3" 
           placeholder="Contact Number" 
           required>
    <button type="submit" 
            name="add_doctor" 
            class="btn btn-success">
        Add Doctor
    </button>
    <a class="btn btn-warning" href="../admin/dashboard.php">
        Goto Dashboard
    </a>
</form>
<br>
<?php echo $msg; ?>
</div>

<?php include '../iincludes/footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
