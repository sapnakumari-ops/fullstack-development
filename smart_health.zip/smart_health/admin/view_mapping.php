<?php 
   session_start();
    if(!isset($_SESSION['userid'])){
        header("location:login.php");
    }
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Health Prediction</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">

   
    <link rel="stylesheet" href="/smart_health/css/style.css">
</head>
<body>

<?php include '../iincludes/header.php'; ?>

<div class="container mt-4">
<h3 class="mb-4"><b>View Disease-Symptom Mapping</b></h3>

<?php
include '../config/db.php';
     $conn =mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DBNAME);

$qry = "select * from doctors";

$result = mysqli_query($conn, $qry);

if(mysqli_num_rows($result) > 0)
{
    echo "<table class='table table-hover table-bordered'>";
    echo "<tr class='table-dark'>";
    echo "<th>Disease Name</th>";
    echo "<th>Symptoms</th>";
    echo "<th>Action</th>";
    echo "</tr>";

   while($row = mysqli_fetch_assoc($result))
{
    echo "<tr>";
    echo "<td>{$row['disease_name']}</td>";
    echo "<td>{$row['symptoms']}</td>";
    echo "<td>
            <a class='btn btn-info btn-sm me-3' href='view_mapping.php?sid=".$row['symptom_id']."'>View</a>
            <a class='btn btn-warning btn-sm' href='delete_mapping.php?id=".$row['symptom_id']."'>Delete</a>
          </td>";
    echo "</tr>";
}


    echo "</table>";
}
else
{
    echo "<h2 class='text-warning'>No Mapping Found !!!</h2>";
}

mysqli_close($conn);
?>

<a href="../admin/dashboard.php" class="btn btn-primary">Back to Dashboard</a>
</div>

<?php include '../iincludes/footer.php'; ?>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

    
