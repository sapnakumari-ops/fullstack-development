<?php 
   session_start();
    if(!isset($_SESSION['userid'])){
        header("location:login.php");
    }
 $msg = "";
 if(isset($_POST['add_disease'])){
        $dname = $_POST['disease'];
        $desc = $_POST['description'];
       include '../config/db.php';
       $conn =mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DBNAME);
        $qry= "insert into diseases(disease_name,description) values('$dname','$desc')";
    mysqli_query($conn, $qry);
       if(mysqli_affected_rows($conn)>0)
          $msg="<b class='text-success'>Disease Added Successfully !!!!!!!!!</b>";
           else
             $msg="<b class='text-danger'>Error in adding the disease !!!!</b>";
                mysqli_close($conn);
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Health Prediction</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">

    <link rel="stylesheet" href="/smart_health/css/style.css">
</head>
<body>

<?php include '../iincludes/header.php'; ?>

<div class="container  mt-5" style=" mini-height: 550px;">
   <h3>Add Disease</h3>
   <form method="post">
    <input type= "text" name="disease" class="form-control mb-3" placeholder="Disease Name" required>
    <textarea name="description" class="form-control mb-3" placeholder="Description"></textarea> 
    <button type="submit" name="add_disease" class="btn btn-success">Add Disease</button>
    <a class="btn btn-warning" href ="../admin/dashboard.php">Goto Dashboard</a>
</form>
 <?php 
 echo $msg;
 ?>
</div>

<?php include '../iincludes/footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
