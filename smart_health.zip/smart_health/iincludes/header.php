
<header class="main-header" bac>
    <div class="logo">Smart Health</div>
    <nav>
        <a href="/smart_health/index.php">Home</a>
        <a href="/smart_health/user/register.php">Register</a>
        <a href="/smart_health/user/login.php">Login</a>
        <a href="/smart_health/admin/view_doctors.php">Doctors</a>
        <a href="/smart_health/contact.php">Contact</a>
    </nav>
</header>
