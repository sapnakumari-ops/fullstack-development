
<style>
html, body {
    height: 100%;
    margin: 0;
}

body {
    display: flex;
    flex-direction: column;
    min-height: 100vh; 
}

.container {
    flex: 1; 
}

.footer {
    background-color: black;
    color: white;
    text-align: center;
    padding: 6px;
    margin-top: auto; 
}
</style>


<div class="footer bg-dark text-white text-center py-3 mt-auto">
    Smart Health Prediction System <br>
    © Reserved by Sapna Kumari
</div>

