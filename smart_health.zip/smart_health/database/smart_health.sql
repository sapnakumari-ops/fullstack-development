-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 02, 2026 at 07:35 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smart_health`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `username`, `password`) VALUES
(1001, 'admin', 'admin@123'),
(1002, 'sapna', 'sapna@123');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `message`, `created_at`) VALUES
(1, 'Sapna', 'sapna@gmail.com', 'Website bahut accha hai!', '2026-02-23 21:14:28');

-- --------------------------------------------------------

--
-- Table structure for table `diseases`
--

CREATE TABLE `diseases` (
  `disease_id` int(11) NOT NULL,
  `disease_name` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `diseases`
--

INSERT INTO `diseases` (`disease_id`, `disease_name`, `description`) VALUES
(1, 'Common Cold', 'A mild viral infection causing runny nose, sneezing, and sore throat.'),
(2, 'Flu', 'A viral illness with fever, cough, body pain, and weakness.'),
(3, 'COVID-19', 'A contagious viral disease-causing fever, dry cough, and loss of smell or taste.'),
(4, 'Dengue', 'A mosquito-borne disease-causing high fever, joint pain, and fatigue.'),
(5, 'Malaria', 'A mosquito-borne illness marked by fever, chills, and body pain.'),
(6, 'Typhoid', 'A bacterial infection from contaminated food or water causing high fever and weakness.'),
(7, 'Asthma', 'A chronic condition causing shortness of breath, cough, and chest tightness.'),
(8, 'Bronchitis', 'Inflammation of airways causing cough, fever, and fatigue.'),
(9, 'Migraine', 'A severe headache disorder with nausea and sensitivity to light.'),
(10, 'Food Poisoning', 'Illness caused by contaminated food leading to vomiting and diarrhea.'),
(11, 'Gastritis', 'Inflammation of the stomach lining causing abdominal pain and nausea.'),
(12, 'Acidity', 'A digestive problem causing heartburn, chest discomfort, and nausea.'),
(13, 'Appendicitis', 'Inflammation of the appendix causing abdominal pain, fever, and nausea.'),
(14, 'Diabetes', 'A metabolic disorder causing frequent urination, increased thirst, and fatigue.'),
(15, 'Hypertension', 'High blood pressure that may cause headache, dizziness, and chest pain.'),
(16, 'Heart Disease', 'A condition affecting the heart causing chest pain, breathlessness, and fatigue.'),
(17, 'Anemia', 'A blood disorder causing fatigue, dizziness, and pale skin.'),
(18, 'Arthritis', 'Inflammation of joints causing pain, swelling, and stiffness.'),
(19, 'Back Pain Disorder', 'A condition causing persistent back pain, muscle stiffness, and tiredness.'),
(20, 'Ear Infection', 'Infection of the ear causing ear pain, fever, and hearing difficulty.'),
(21, 'Kidney Stone', 'A painful condition caused by stones in kidneys leading to back pain and nausea.'),
(22, 'Depression', 'A mental health condition marked by sadness, loss of interest, and sleep problems.'),
(23, 'Allergy', 'An immune reaction causing sneezing, runny nose, and itchy eyes.'),
(24, 'Heat Stroke', 'A serious condition due to overheating causing high body temperature and dizziness.'),
(25, 'Sinusitis', 'Inflammation of sinus cavities causing headache and nasal blockage.'),
(26, 'Tonsillitis', 'Inflammation of tonsils causing sore throat and difficulty swallowing.'),
(27, 'Urinary Tract Infection (UTI)', 'An infection in the urinary system causing burning urination and frequent urination.'),
(28, 'Kidney Stone', 'Hard mineral deposits formed in kidneys causing severe back pain.'),
(29, 'Jaundice', 'A condition where the skin and eyes turn yellow due to liver problems.'),
(30, ' Anxiety Disorder', 'A mental condition characterized by excessive fear, nervousness, and worry.'),
(31, 'Dehydration', 'A condition that occurs when the body loses more fluids than it takes in.'),
(32, 'Insomnia', 'A sleep disorder in which a person finds difficulty in falling or staying asleep.');

-- --------------------------------------------------------

--
-- Table structure for table `disease_symptom`
--

CREATE TABLE `disease_symptom` (
  `id` int(11) NOT NULL,
  `disease_id` int(11) DEFAULT NULL,
  `symptom_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `disease_symptom`
--

INSERT INTO `disease_symptom` (`id`, `disease_id`, `symptom_id`) VALUES
(1, 2, 4),
(2, 2, 5),
(3, 2, 6),
(4, 3, 4),
(5, 3, 7),
(6, 3, 10),
(7, 6, 8),
(8, 6, 9),
(9, 6, 12),
(10, 20, 4),
(11, 20, 44),
(12, 20, 45),
(13, 14, 12),
(14, 14, 22),
(15, 14, 25);

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `doctor_id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `specialization` varchar(50) DEFAULT NULL,
  `contact` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`doctor_id`, `name`, `specialization`, `contact`) VALUES
(1, 'Dr. Amit Sharma', 'General Physician', ' 9876543210'),
(2, 'Dr. Neha Verma', 'General Medicine', '9823456712'),
(3, 'Dr. Rajesh Singh', 'Internal Medicine', '9898765432'),
(4, 'Dr. Priya Mehta', 'Pulmonologist', '9812345678'),
(5, 'Dr. Arvind Kumar', 'Chest Specialist', '9876123456'),
(6, 'Dr. Suresh Patel', 'Cardiologist', '9898012345'),
(7, 'Dr. Kavita Iyer', 'Heart Specialist', '9823012345'),
(8, 'Dr. Rohit Bansal', 'Neurologist', ' 9811198765'),
(9, 'Dr. Pooja Nair', 'Gastroenterologist', ' 9845012345'),
(10, ' Dr. Manish Gupta', ' Digestive Specialist', ' 9833012345'),
(11, ' Dr. Vikram Joshi', 'Orthopedic', '9890123456'),
(12, 'Dr. Anjali Rao', 'Orthopedic Surgeon', '9822098765'),
(13, 'Dr. Sneha Kulkarni', 'Diabetologist', '9876501234'),
(14, ' Dr. Rakesh Menon', 'Endocrinologist', ' 9810098765'),
(15, 'Dr. Harish Choudhary', 'Nephrologist', '9876123098'),
(16, 'Dr. Meenakshi Reddy', 'Dermatologist', '9898761203'),
(17, ' Dr. Ankit Tiwari', ' Psychiatrist', ' 9823456789'),
(18, 'Dr. Shalini Desai', 'Clinical Psychologist', '9815678902'),
(19, 'Dr. Deepak Malhotra', 'ENT Specialist', ' 9845678901'),
(20, 'Dr. Ritu Kapoor', 'ENT Surgeon', ' 9876509876'),
(21, ' Dr. Karan Malviya', ' Emergency Medicine', '9898901234');

-- --------------------------------------------------------

--
-- Table structure for table `symptoms`
--

CREATE TABLE `symptoms` (
  `symptom_id` int(11) NOT NULL,
  `symptom_name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `symptoms`
--

INSERT INTO `symptoms` (`symptom_id`, `symptom_name`) VALUES
(1, ' Cold '),
(2, ' Runny Nose '),
(3, '  Sneezing '),
(4, 'Fever'),
(5, ' Cough'),
(6, 'Body Pain'),
(7, 'Dry Cough'),
(8, 'High Fever'),
(9, 'Joint Pain '),
(10, 'Loss of Smell'),
(12, 'Fatigue'),
(13, 'Chills'),
(14, 'Headache'),
(15, 'Weakness'),
(16, 'Chest Pain'),
(17, 'Shortness of Breath'),
(18, 'Chest Tightness'),
(19, 'Diarrhea'),
(20, 'Nausea'),
(21, 'Vomiting'),
(22, 'Increased Thirst'),
(23, 'Heartburn'),
(24, 'Abdominal Pain'),
(25, 'Frequent Urination'),
(26, 'Chest Discomfort'),
(27, 'Dizziness'),
(28, 'Swelling'),
(29, 'Stiffness'),
(30, 'Pale Skin'),
(31, 'Back Pain'),
(32, 'Muscle Stiffness'),
(33, 'Facial Pain'),
(34, 'Nasal Congestion'),
(35, 'Sneezing'),
(36, 'Itchy Eyes'),
(37, 'Sore Throat'),
(38, 'Difficulty Swallowing'),
(39, 'Reduced Urination'),
(40, 'Dry Mouth'),
(41, 'High Body Temperature'),
(42, 'Irritability'),
(43, 'Difficulty Swallowing'),
(44, 'Ear Pain'),
(45, 'Hearing Difficulty'),
(46, 'Burning Urination'),
(47, 'Lower Abdominal Pain'),
(48, 'Severe Back Pain'),
(49, 'Sadness'),
(50, 'Dark Urine'),
(51, 'Yellow Skin'),
(52, 'Blood in Urine'),
(53, 'Loss of Interest'),
(54, 'Sleep Problems'),
(55, 'Nervousness'),
(56, 'Rapid Heartbeat'),
(57, 'Sweating');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `gender` varchar(15) DEFAULT NULL,
  `mobile_no` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `email`, `password`, `gender`, `mobile_no`) VALUES
(1001, 'sapna kumari', 'sapna@outlook.com', '123456', '', 8956789894),
(1002, 'kavya singh', 'kavya@gmail.com', '123784', 'Female', 9994567834);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `diseases`
--
ALTER TABLE `diseases`
  ADD PRIMARY KEY (`disease_id`);

--
-- Indexes for table `disease_symptom`
--
ALTER TABLE `disease_symptom`
  ADD PRIMARY KEY (`id`),
  ADD KEY `disease_id` (`disease_id`),
  ADD KEY `symptom_id` (`symptom_id`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`doctor_id`);

--
-- Indexes for table `symptoms`
--
ALTER TABLE `symptoms`
  ADD PRIMARY KEY (`symptom_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1003;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `diseases`
--
ALTER TABLE `diseases`
  MODIFY `disease_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `disease_symptom`
--
ALTER TABLE `disease_symptom`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `doctor_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `symptoms`
--
ALTER TABLE `symptoms`
  MODIFY `symptom_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1003;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `disease_symptom`
--
ALTER TABLE `disease_symptom`
  ADD CONSTRAINT `disease_symptom_ibfk_1` FOREIGN KEY (`disease_id`) REFERENCES `diseases` (`disease_id`),
  ADD CONSTRAINT `disease_symptom_ibfk_2` FOREIGN KEY (`symptom_id`) REFERENCES `symptoms` (`symptom_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
